help() {
  echo "figure it tf out lol"
}
